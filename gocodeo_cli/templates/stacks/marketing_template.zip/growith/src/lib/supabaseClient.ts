import { createBrowserSupabaseClient } from '@supabase/auth-helpers-nextjs';
import { Database } from '@/types/supabase';

// Always use this for client-side Supabase calls
export const supabase = createBrowserSupabaseClient<Database>();
