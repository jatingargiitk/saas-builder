# Security Guidelines

- Never commit secret keys or credentials to the repository.
- Use environment variables for all secrets and keys.
- All user input must be validated and sanitized.
- Use HTTPS in production.
- Apply all security patches and keep dependencies up to date.
- Follow Supabase RLS best practices for data protection.
