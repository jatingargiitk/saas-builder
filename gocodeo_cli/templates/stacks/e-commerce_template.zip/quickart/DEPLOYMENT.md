# Deployment Guide

## Deploying to Vercel

1. Fork and clone the repository.
2. Push your repo to GitHub.
3. Connect your repo to [Vercel](https://vercel.com/).
4. Set environment variables in Vercel Dashboard:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
5. Run database migrations in Supabase SQL Editor using files from `/migrations` in order.
6. Deploy!

## Manual Deployment

1. Build the app:
   ```sh
   npm run build
   ```
2. Start the app:
   ```sh
   npm run start
   ```
