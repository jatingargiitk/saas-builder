# Contributing to Amazona

## How to Contribute

1. Fork this repository and clone it locally.
2. Create a new branch for your feature or bugfix.
3. Write clear, maintainable code with proper TypeScript types and documentation.
4. Run linting and tests before submitting a PR.
5. Submit a pull request with a detailed description of your changes.

## Code Style

- Use Prettier for code formatting (`npm run format`).
- Use ESLint for linting (`npm run lint`).
- Write descriptive commit messages.

## Feature Requests

- Please open an issue to discuss new features before submitting code.

## Reporting Bugs

- Open an issue and provide as much detail as possible, including steps to reproduce.
