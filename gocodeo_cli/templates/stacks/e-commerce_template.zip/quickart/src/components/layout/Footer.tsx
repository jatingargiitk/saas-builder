export default function Footer() {
  return (
    <footer className="w-full mt-auto bg-background/90 border-t border-muted py-6 shadow-card">
      <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
        <span className="text-muted-foreground text-sm">&copy; {new Date().getFullYear()} Amazona. All rights reserved.</span>
        <div className="flex gap-4 text-sm">
          <a href="#faq" className="hover:text-primary transition-colors">FAQ</a>
          <a href="#contact" className="hover:text-primary transition-colors">Contact</a>
        </div>
      </div>
    </footer>
  );
}
