export default function ProductDetailSkeleton() {
  return (
    <div className="flex flex-col md:flex-row gap-10 animate-pulse">
      <div className="w-full md:w-[400px] h-[400px] bg-gray-200 rounded-3xl" />
      <div className="flex-1 flex flex-col gap-4">
        <div className="h-10 w-2/3 bg-gray-200 rounded" />
        <div className="h-6 w-1/3 bg-gray-200 rounded" />
        <div className="h-4 w-full bg-gray-200 rounded" />
        <div className="h-4 w-1/2 bg-gray-200 rounded" />
        <div className="h-4 w-1/4 bg-gray-200 rounded" />
      </div>
    </div>
  );
}
