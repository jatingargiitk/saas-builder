export interface CartItem {
  id: string; // Supabase UUID for cart row
  user_id: string;
  product_id: string;
  quantity: number;
  created_at: string;
  product?: {
    id: string;
    title: string;
    description: string;
    price: number;
    image_url: string;
    category: string;
    created_at: string;
    updated_at: string;
  };
}
