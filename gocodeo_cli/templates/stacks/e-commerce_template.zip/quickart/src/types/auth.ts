import type { Session, User } from '@supabase/auth-helpers-nextjs';

export interface AuthState {
  session: Session | null;
  user: User | null;
  loading: boolean;
  error: string | null;
}
