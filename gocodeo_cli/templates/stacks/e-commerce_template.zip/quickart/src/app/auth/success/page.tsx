export default function AuthSuccess() {
  return (
    <section className="min-h-[70vh] flex flex-col items-center justify-center">
      <div className="rounded-2xl bg-background/90 shadow-glass px-8 py-10 text-center border border-muted max-w-md">
        <h1 className="font-heading text-2xl font-bold mb-4 text-primary">Account Created</h1>
        <p className="text-muted-foreground mb-4">Your account has been created. Please check your email and confirm your address to complete sign up.</p>
        <a href="/auth/login" className="inline-block px-6 py-2 rounded-lg bg-primary text-primary-foreground font-semibold shadow-card hover:bg-secondary transition-colors">Go to login</a>
      </div>
    </section>
  );
}
