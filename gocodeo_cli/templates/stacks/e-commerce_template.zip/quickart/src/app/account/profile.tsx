export { default } from '@/components/account/ProfileCard';
