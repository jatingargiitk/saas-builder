export { default } from '@/app/auth/loading';
