import type { ReactNode } from 'react';
import AuthGuard from '@/components/ui/AuthGuard';

export default function AccountLayout({ children }: { children: ReactNode }) {
  return <AuthGuard>{children}</AuthGuard>;
}
