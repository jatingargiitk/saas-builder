export { default } from '@/app/auth/success/page';
