import { useState } from 'react';

export default function Settings() {
  const [activeTab, setActiveTab] = useState('account');
  
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Settings</h2>
        <p className="text-muted-foreground">Manage your account settings and preferences.</p>
      </div>

      {/* Settings tabs */}
      <div className="flex border-b">
        <button
          onClick={() => setActiveTab('account')}
          className={`px-4 py-2 text-sm font-medium ${
            activeTab === 'account'
              ? 'border-b-2 border-primary text-primary'
              : 'text-muted-foreground'
          }`}
        >
          Account
        </button>
        <button
          onClick={() => setActiveTab('notifications')}
          className={`px-4 py-2 text-sm font-medium ${
            activeTab === 'notifications'
              ? 'border-b-2 border-primary text-primary'
              : 'text-muted-foreground'
          }`}
        >
          Notifications
        </button>
        <button
          onClick={() => setActiveTab('appearance')}
          className={`px-4 py-2 text-sm font-medium ${
            activeTab === 'appearance'
              ? 'border-b-2 border-primary text-primary'
              : 'text-muted-foreground'
          }`}
        >
          Appearance
        </button>
        <button
          onClick={() => setActiveTab('security')}
          className={`px-4 py-2 text-sm font-medium ${
            activeTab === 'security'
              ? 'border-b-2 border-primary text-primary'
              : 'text-muted-foreground'
          }`}
        >
          Security
        </button>
      </div>

      {/* Tab content */}
      <div className="mt-6">
        {activeTab === 'account' && (
          <div className="space-y-6">
            <div className="rounded-lg border bg-card p-6 shadow-sm">
              <h3 className="text-lg font-medium">Personal Information</h3>
              <div className="mt-4 grid gap-4">
                <div className="grid gap-2">
                  <label className="text-sm font-medium leading-none">
                    Display Name
                  </label>
                  <input
                    type="text"
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                    defaultValue="John Smith"
                  />
                </div>
                <div className="grid gap-2">
                  <label className="text-sm font-medium leading-none">
                    Email
                  </label>
                  <input
                    type="email"
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                    defaultValue="john.smith@company.com"
                  />
                </div>
                <div className="grid gap-2">
                  <label className="text-sm font-medium leading-none">
                    Bio
                  </label>
                  <textarea
                    className="flex min-h-[100px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                    defaultValue="Software engineer with 5+ years experience in web development."
                  />
                </div>
                <div className="flex justify-end">
                  <button className="inline-flex h-10 items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground">
                    Save Changes
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
        
        {activeTab === 'notifications' && (
          <div className="space-y-6">
            <div className="rounded-lg border bg-card p-6 shadow-sm">
              <h3 className="text-lg font-medium">Email Notifications</h3>
              <div className="mt-4 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Leave Requests</p>
                    <p className="text-sm text-muted-foreground">
                      Receive emails for new leave requests and updates
                    </p>
                  </div>
                  <label className="relative inline-flex cursor-pointer items-center">
                    <input type="checkbox" className="peer sr-only" defaultChecked />
                    <div className="peer h-6 w-11 rounded-full bg-muted after:absolute after:left-[2px] after:top-[2px] after:h-5 after:w-5 after:rounded-full after:bg-white after:transition-all after:content-[''] peer-checked:bg-primary peer-checked:after:translate-x-full"></div>
                  </label>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Payroll Updates</p>
                    <p className="text-sm text-muted-foreground">
                      Receive emails when your payslip is available
                    </p>
                  </div>
                  <label className="relative inline-flex cursor-pointer items-center">
                    <input type="checkbox" className="peer sr-only" defaultChecked />
                    <div className="peer h-6 w-11 rounded-full bg-muted after:absolute after:left-[2px] after:top-[2px] after:h-5 after:w-5 after:rounded-full after:bg-white after:transition-all after:content-[''] peer-checked:bg-primary peer-checked:after:translate-x-full"></div>
                  </label>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Announcements</p>
                    <p className="text-sm text-muted-foreground">
                      Receive emails for company announcements
                    </p>
                  </div>
                  <label className="relative inline-flex cursor-pointer items-center">
                    <input type="checkbox" className="peer sr-only" />
                    <div className="peer h-6 w-11 rounded-full bg-muted after:absolute after:left-[2px] after:top-[2px] after:h-5 after:w-5 after:rounded-full after:bg-white after:transition-all after:content-[''] peer-checked:bg-primary peer-checked:after:translate-x-full"></div>
                  </label>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Performance Reviews</p>
                    <p className="text-sm text-muted-foreground">
                      Receive emails for upcoming and completed reviews
                    </p>
                  </div>
                  <label className="relative inline-flex cursor-pointer items-center">
                    <input type="checkbox" className="peer sr-only" defaultChecked />
                    <div className="peer h-6 w-11 rounded-full bg-muted after:absolute after:left-[2px] after:top-[2px] after:h-5 after:w-5 after:rounded-full after:bg-white after:transition-all after:content-[''] peer-checked:bg-primary peer-checked:after:translate-x-full"></div>
                  </label>
                </div>
              </div>
            </div>
          </div>
        )}
        
        {activeTab === 'appearance' && (
          <div className="space-y-6">
            <div className="rounded-lg border bg-card p-6 shadow-sm">
              <h3 className="text-lg font-medium">Theme</h3>
              <div className="mt-4 grid grid-cols-3 gap-4">
                <div className="rounded-lg border border-primary bg-card p-4 text-center">
                  <div className="h-12 rounded bg-background"></div>
                  <p className="mt-2 text-sm font-medium">Light</p>
                </div>
                <div className="rounded-lg border bg-card p-4 text-center">
                  <div className="h-12 rounded bg-slate-800"></div>
                  <p className="mt-2 text-sm font-medium">Dark</p>
                </div>
                <div className="rounded-lg border bg-card p-4 text-center">
                  <div className="h-12 rounded bg-gradient-to-r from-background to-slate-800"></div>
                  <p className="mt-2 text-sm font-medium">System</p>
                </div>
              </div>
            </div>
            
            <div className="rounded-lg border bg-card p-6 shadow-sm">
              <h3 className="text-lg font-medium">Dashboard Layout</h3>
              <div className="mt-4 grid gap-2">
                <label className="flex items-center space-x-2">
                  <input type="radio" name="layout" className="h-4 w-4 border-primary text-primary" defaultChecked />
                  <span>Default Layout</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input type="radio" name="layout" className="h-4 w-4 border-primary text-primary" />
                  <span>Compact Layout</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input type="radio" name="layout" className="h-4 w-4 border-primary text-primary" />
                  <span>Expanded Layout</span>
                </label>
              </div>
            </div>
          </div>
        )}
        
        {activeTab === 'security' && (
          <div className="space-y-6">
            <div className="rounded-lg border bg-card p-6 shadow-sm">
              <h3 className="text-lg font-medium">Change Password</h3>
              <div className="mt-4 grid gap-4">
                <div className="grid gap-2">
                  <label className="text-sm font-medium leading-none">
                    Current Password
                  </label>
                  <input
                    type="password"
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                  />
                </div>
                <div className="grid gap-2">
                  <label className="text-sm font-medium leading-none">
                    New Password
                  </label>
                  <input
                    type="password"
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                  />
                </div>
                <div className="grid gap-2">
                  <label className="text-sm font-medium leading-none">
                    Confirm New Password
                  </label>
                  <input
                    type="password"
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                  />
                </div>
                <div className="flex justify-end">
                  <button className="inline-flex h-10 items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground">
                    Update Password
                  </button>
                </div>
              </div>
            </div>
            
            <div className="rounded-lg border bg-card p-6 shadow-sm">
              <h3 className="text-lg font-medium">Two-Factor Authentication</h3>
              <div className="mt-4">
                <p className="text-sm text-muted-foreground">
                  Enhance your account security by enabling two-factor authentication.
                </p>
                <div className="mt-4">
                  <button className="inline-flex h-10 items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground">
                    Enable 2FA
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
} 