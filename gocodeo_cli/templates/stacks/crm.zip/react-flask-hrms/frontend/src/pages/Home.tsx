import { Link } from 'react-router-dom';

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Header/Navigation */}
      <header className="border-b bg-background">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <div className="flex items-center">
            <span className="text-xl font-bold">HRMS</span>
          </div>
          <nav className="hidden md:flex gap-6">
            <a href="#features" className="text-sm font-medium">Features</a>
            <a href="#testimonials" className="text-sm font-medium">Testimonials</a>
            <a href="#pricing" className="text-sm font-medium">Pricing</a>
            <a href="#contact" className="text-sm font-medium">Contact</a>
          </nav>
          <div>
            <Link
              to="/auth/login"
              className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground shadow transition-colors hover:bg-primary/90"
            >
              Sign In
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-grow">
        {/* Hero Section */}
        <section className="relative py-20 md:py-32 overflow-hidden">
          <div className="container mx-auto px-4">
            <div className="grid gap-12 md:grid-cols-2 md:gap-16 items-center">
              <div>
                <h1 className="text-4xl font-bold tracking-tight md:text-5xl lg:text-6xl">
                  Streamline Your HR Management
                </h1>
                <p className="mt-6 text-lg text-muted-foreground">
                  A comprehensive human resource management system designed to simplify 
                  employee management, attendance tracking, leave management, and payroll processing.
                </p>
                <div className="mt-8 flex flex-wrap gap-4">
                  <Link
                    to="/dashboard"
                    className="inline-flex h-10 items-center justify-center rounded-md bg-primary px-8 text-sm font-medium text-primary-foreground shadow transition-colors hover:bg-primary/90"
                  >
                    Dashboard Demo
                  </Link>
                  <Link
                    to="/auth/register"
                    className="inline-flex h-10 items-center justify-center rounded-md border border-input bg-background px-8 text-sm font-medium shadow-sm hover:bg-accent hover:text-accent-foreground"
                  >
                    Sign Up
                  </Link>
                </div>
              </div>
              <div className="relative mx-auto w-full max-w-md">
                <div className="rounded-xl bg-gradient-to-b from-primary/20 to-primary/5 p-1 shadow-lg">
                  <img
                    src="https://images.unsplash.com/photo-1551434678-e076c223a692?w=800&h=600&q=80"
                    alt="HRMS Dashboard"
                    className="rounded-lg"
                  />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Features */}
        <section id="features" className="py-16 bg-accent/30">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold">Key Features</h2>
              <p className="mt-4 text-muted-foreground">
                Everything you need to manage your workforce effectively
              </p>
            </div>
            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
              <div className="rounded-lg border bg-card p-6 shadow-sm">
                <h3 className="text-xl font-semibold mb-3">Employee Management</h3>
                <p className="text-muted-foreground">
                  Maintain comprehensive employee records and profiles with ease.
                </p>
              </div>
              
              <div className="rounded-lg border bg-card p-6 shadow-sm">
                <h3 className="text-xl font-semibold mb-3">Attendance Tracking</h3>
                <p className="text-muted-foreground">
                  Track employee attendance with precision and generate reports.
                </p>
              </div>
              
              <div className="rounded-lg border bg-card p-6 shadow-sm">
                <h3 className="text-xl font-semibold mb-3">Leave Management</h3>
                <p className="text-muted-foreground">
                  Efficiently manage leave requests and approvals with a kanban board.
                </p>
              </div>
              
              <div className="rounded-lg border bg-card p-6 shadow-sm">
                <h3 className="text-xl font-semibold mb-3">Payroll Processing</h3>
                <p className="text-muted-foreground">
                  Automate payroll calculations and generate payment reports.
                </p>
              </div>
              
              <div className="rounded-lg border bg-card p-6 shadow-sm">
                <h3 className="text-xl font-semibold mb-3">Reporting & Analytics</h3>
                <p className="text-muted-foreground">
                  Generate comprehensive reports for informed decision-making.
                </p>
              </div>
              
              <div className="rounded-lg border bg-card p-6 shadow-sm">
                <h3 className="text-xl font-semibold mb-3">Mobile Friendly</h3>
                <p className="text-muted-foreground">
                  Access your HR system anywhere, anytime, on any device.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Testimonials */}
        <section id="testimonials" className="py-16">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold">What Our Clients Say</h2>
              <p className="mt-4 text-muted-foreground">
                Trusted by companies of all sizes
              </p>
            </div>
            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
              <div className="rounded-lg border bg-card p-6 shadow-sm">
                <p className="italic text-muted-foreground mb-4">
                  "This HRMS system has revolutionized how we manage our workforce. Highly recommended!"
                </p>
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                    JD
                  </div>
                  <div>
                    <p className="font-medium">Jane Doe</p>
                    <p className="text-sm text-muted-foreground">HR Director, TechCorp</p>
                  </div>
                </div>
              </div>
              
              <div className="rounded-lg border bg-card p-6 shadow-sm">
                <p className="italic text-muted-foreground mb-4">
                  "The attendance tracking and leave management features have saved us countless hours."
                </p>
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                    JS
                  </div>
                  <div>
                    <p className="font-medium">John Smith</p>
                    <p className="text-sm text-muted-foreground">CEO, StartupX</p>
                  </div>
                </div>
              </div>
              
              <div className="rounded-lg border bg-card p-6 shadow-sm">
                <p className="italic text-muted-foreground mb-4">
                  "Payroll processing used to take days, now it's done in hours. Exceptional system!"
                </p>
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                    AM
                  </div>
                  <div>
                    <p className="font-medium">Alice Miller</p>
                    <p className="text-sm text-muted-foreground">CFO, Enterprise Inc</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t bg-accent/30 py-8">
        <div className="container mx-auto px-4">
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
            <div>
              <h3 className="font-semibold text-lg mb-3">HRMS</h3>
              <p className="text-sm text-muted-foreground">
                A comprehensive human resource management system for modern businesses.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-3">Product</h3>
              <ul className="space-y-2 text-sm">
                <li><a href="#features" className="text-muted-foreground hover:text-foreground">Features</a></li>
                <li><a href="#" className="text-muted-foreground hover:text-foreground">Pricing</a></li>
                <li><a href="#" className="text-muted-foreground hover:text-foreground">Tutorials</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-3">Company</h3>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="text-muted-foreground hover:text-foreground">About</a></li>
                <li><a href="#" className="text-muted-foreground hover:text-foreground">Careers</a></li>
                <li><a href="#contact" className="text-muted-foreground hover:text-foreground">Contact</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-3">Legal</h3>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="text-muted-foreground hover:text-foreground">Privacy</a></li>
                <li><a href="#" className="text-muted-foreground hover:text-foreground">Terms</a></li>
                <li><a href="#" className="text-muted-foreground hover:text-foreground">Cookie Policy</a></li>
              </ul>
            </div>
          </div>
          
          <div className="mt-8 border-t pt-6 text-center text-sm text-muted-foreground">
            &copy; {new Date().getFullYear()} HRMS. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
} 