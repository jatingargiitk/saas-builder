import { useState, useEffect } from 'react';
import axios from 'axios';
import { toast } from 'sonner';
import { useAuth } from '../hooks/useAuth';

interface ProfileData {
  name: string;
  email: string;
  position: string;
  department: string;
  phone: string;
  address: string;
  hire_date: string;
  employment_type: string;
}

export default function Profile() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('personal');
  const [isLoading, setIsLoading] = useState(true);
  const [profileData, setProfileData] = useState<ProfileData>({
    name: '',
    email: '',
    position: '',
    department: '',
    phone: '',
    address: '',
    hire_date: '',
    employment_type: ''
  });
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState<Partial<ProfileData>>({});
  
  // Get user initials for avatar
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n.charAt(0))
      .join('')
      .toUpperCase();
  };
  
  // Format date for display
  const formatDate = (dateString: string) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    }).format(date);
  };
  
  // Calculate years of experience
  const calculateYears = (dateString: string) => {
    if (!dateString) return '0';
    const hireDate = new Date(dateString);
    const now = new Date();
    let years = now.getFullYear() - hireDate.getFullYear();
    
    // Adjust if anniversary hasn't occurred yet this year
    if (
      now.getMonth() < hireDate.getMonth() ||
      (now.getMonth() === hireDate.getMonth() && now.getDate() < hireDate.getDate())
    ) {
      years--;
    }
    
    return years.toString();
  };

  // Load user profile data
  const loadProfileData = async () => {
    try {
      setIsLoading(true);
      
      // Get employee data - will be created if doesn't exist
      try {
        const response = await axios.get('/api/employees/me');
        const employeeData = response.data;
        
        // Update profile data with employee info
        setProfileData({
          name: user?.name || 'John Smith',
          email: user?.email || 'john.smith@company.com',
          position: employeeData?.position || 'Employee',
          department: employeeData?.department || 'General',
          phone: employeeData?.phone || '',
          address: employeeData?.address || '',
          hire_date: employeeData?.hire_date || new Date().toISOString().split('T')[0],
          employment_type: 'Full-time'
        });
      } catch (error) {
        console.error('Error loading employee data:', error);
        // If API call fails, use fallback data from user context
        setProfileData({
          name: user?.name || 'John Smith',
          email: user?.email || 'john.smith@company.com',
          position: 'Employee',
          department: 'General',
          phone: '',
          address: '',
          hire_date: new Date().toISOString().split('T')[0],
          employment_type: 'Full-time'
        });
      }
      
      setEditForm({});
    } finally {
      setIsLoading(false);
    }
  };
  
  // Handle form input changes
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setEditForm(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  // Save profile changes
  const saveProfileChanges = async () => {
    try {
      setIsLoading(true);
      
      // Only update employee info - user name/email would need separate endpoints
      if (editForm.phone || editForm.address) {
        try {
          await axios.put('/api/employees/me', {
            phone: editForm.phone || profileData.phone,
            address: editForm.address || profileData.address
          });
          toast.success('Profile updated successfully');
          
          // Update local state with changes
          setProfileData(prev => ({
            ...prev,
            ...editForm
          }));
          
          setIsEditing(false);
          setEditForm({});
        } catch (error) {
          console.error('Could not update employee record', error);
          toast.error('Failed to update profile information');
        }
      } else {
        // If no actual changes, just exit edit mode
        setIsEditing(false);
        setEditForm({});
      }
    } finally {
      setIsLoading(false);
    }
  };

  // Load data on component mount
  useEffect(() => {
    if (user) {
      loadProfileData();
    }
  }, [user]);
  
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Profile</h2>
        <p className="text-muted-foreground">Manage your personal information and settings.</p>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-8">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
        </div>
      ) : (
        <>
          {/* Profile header */}
          <div className="rounded-lg border bg-card p-6 shadow-sm">
            <div className="flex flex-col md:flex-row md:items-center md:gap-8">
              <div className="h-24 w-24 rounded-full bg-primary/10 flex items-center justify-center text-4xl font-semibold text-primary">
                {getInitials(profileData.name)}
              </div>
              <div className="mt-4 md:mt-0">
                <h3 className="text-2xl font-bold">{profileData.name}</h3>
                <p className="text-muted-foreground">{profileData.position}</p>
                <div className="mt-2 flex flex-wrap gap-2">
                  <span className="inline-flex items-center rounded-md bg-primary/10 px-2 py-1 text-xs font-medium text-primary">
                    {profileData.department}
                  </span>
                  <span className="inline-flex items-center rounded-md bg-green-100 px-2 py-1 text-xs font-medium text-green-800">
                    {profileData.employment_type}
                  </span>
                  <span className="inline-flex items-center rounded-md bg-blue-100 px-2 py-1 text-xs font-medium text-blue-800">
                    {calculateYears(profileData.hire_date)} Years
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Profile tabs */}
          <div className="flex border-b">
            <button
              onClick={() => setActiveTab('personal')}
              className={`px-4 py-2 text-sm font-medium ${
                activeTab === 'personal'
                  ? 'border-b-2 border-primary text-primary'
                  : 'text-muted-foreground'
              }`}
            >
              Personal Information
            </button>
            <button
              onClick={() => setActiveTab('employment')}
              className={`px-4 py-2 text-sm font-medium ${
                activeTab === 'employment'
                  ? 'border-b-2 border-primary text-primary'
                  : 'text-muted-foreground'
              }`}
            >
              Employment
            </button>
            <button
              onClick={() => setActiveTab('performance')}
              className={`px-4 py-2 text-sm font-medium ${
                activeTab === 'performance'
                  ? 'border-b-2 border-primary text-primary'
                  : 'text-muted-foreground'
              }`}
            >
              Performance
            </button>
            <button
              onClick={() => setActiveTab('documents')}
              className={`px-4 py-2 text-sm font-medium ${
                activeTab === 'documents'
                  ? 'border-b-2 border-primary text-primary'
                  : 'text-muted-foreground'
              }`}
            >
              Documents
            </button>
          </div>

          {/* Tab content */}
          <div className="mt-6">
            {activeTab === 'personal' && (
              <div className="space-y-6">
                {isEditing ? (
                  <div className="grid gap-6 md:grid-cols-2">
                    <div>
                      <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                        Full Name
                      </label>
                      <input
                        type="text"
                        name="name"
                        className="mt-2 flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                        value={editForm.name || profileData.name}
                        onChange={handleInputChange}
                        disabled={true} // Name can only be changed through account settings
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                        Email
                      </label>
                      <input
                        type="email"
                        name="email"
                        className="mt-2 flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                        value={editForm.email || profileData.email}
                        onChange={handleInputChange}
                        disabled={true} // Email can only be changed through account settings
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                        Phone Number
                      </label>
                      <input
                        type="tel"
                        name="phone"
                        className="mt-2 flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                        value={editForm.phone !== undefined ? editForm.phone : profileData.phone}
                        onChange={handleInputChange}
                      />
                    </div>
                    <div className="md:col-span-2">
                      <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                        Address
                      </label>
                      <input
                        type="text"
                        name="address"
                        className="mt-2 flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                        value={editForm.address !== undefined ? editForm.address : profileData.address}
                        onChange={handleInputChange}
                      />
                    </div>
                  </div>
                ) : (
                  <div className="grid gap-6 md:grid-cols-2">
                    <div>
                      <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                        Full Name
                      </label>
                      <input
                        type="text"
                        className="mt-2 flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                        value={profileData.name}
                        readOnly
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                        Email
                      </label>
                      <input
                        type="email"
                        className="mt-2 flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                        value={profileData.email}
                        readOnly
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                        Phone Number
                      </label>
                      <input
                        type="tel"
                        className="mt-2 flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                        value={profileData.phone}
                        readOnly
                      />
                    </div>
                    <div className="md:col-span-2">
                      <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                        Address
                      </label>
                      <input
                        type="text"
                        className="mt-2 flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                        value={profileData.address}
                        readOnly
                      />
                    </div>
                  </div>
                )}
                
                {isEditing ? (
                  <div className="flex space-x-2">
                    <button 
                      onClick={saveProfileChanges}
                      className="inline-flex h-10 items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground"
                      disabled={isLoading}
                    >
                      {isLoading ? 'Saving...' : 'Save Changes'}
                    </button>
                    <button 
                      onClick={() => {
                        setIsEditing(false);
                        setEditForm({});
                      }}
                      className="inline-flex h-10 items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium"
                      disabled={isLoading}
                    >
                      Cancel
                    </button>
                  </div>
                ) : (
                  <button 
                    onClick={() => setIsEditing(true)}
                    className="inline-flex h-10 items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground"
                  >
                    Edit Information
                  </button>
                )}
              </div>
            )}
            
            {activeTab === 'employment' && (
              <div className="space-y-4">
                <div className="rounded-lg border bg-card p-4">
                  <h3 className="font-semibold">Current Position</h3>
                  <div className="mt-2 grid gap-2">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Title</span>
                      <span>{profileData.position}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Department</span>
                      <span>{profileData.department}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Manager</span>
                      <span>Sarah Davis</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Start Date</span>
                      <span>{formatDate(profileData.hire_date)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Employment Type</span>
                      <span>{profileData.employment_type}</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            {activeTab === 'performance' && (
              <div className="space-y-4">
                <div className="rounded-lg border bg-card p-4">
                  <h3 className="font-semibold">Recent Reviews</h3>
                  <div className="mt-4 space-y-4">
                    <div className="rounded border p-4">
                      <div className="flex justify-between">
                        <span className="font-medium">Annual Review 2023</span>
                        <span className="text-sm text-muted-foreground">March 15, 2023</span>
                      </div>
                      <div className="mt-2 flex items-center">
                        <span className="text-sm text-muted-foreground mr-2">Rating:</span>
                        <div className="flex">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <svg
                              key={star}
                              className={`h-4 w-4 ${star <= 4 ? 'text-yellow-400' : 'text-gray-300'}`}
                              fill="currentColor"
                              viewBox="0 0 20 20"
                              xmlns="http://www.w3.org/2000/svg"
                            >
                              <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                            </svg>
                          ))}
                        </div>
                      </div>
                    </div>
                    
                    <div className="rounded border p-4">
                      <div className="flex justify-between">
                        <span className="font-medium">Mid-Year Review 2022</span>
                        <span className="text-sm text-muted-foreground">August 10, 2022</span>
                      </div>
                      <div className="mt-2 flex items-center">
                        <span className="text-sm text-muted-foreground mr-2">Rating:</span>
                        <div className="flex">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <svg
                              key={star}
                              className={`h-4 w-4 ${star <= 4 ? 'text-yellow-400' : 'text-gray-300'}`}
                              fill="currentColor"
                              viewBox="0 0 20 20"
                              xmlns="http://www.w3.org/2000/svg"
                            >
                              <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                            </svg>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            {activeTab === 'documents' && (
              <div className="space-y-4">
                <div className="rounded-lg border bg-card p-4">
                  <h3 className="font-semibold">Documents</h3>
                  <div className="mt-4 space-y-2">
                    <div className="flex items-center justify-between rounded border p-3">
                      <span className="font-medium">Contract.pdf</span>
                      <button className="text-sm text-primary hover:underline">Download</button>
                    </div>
                    <div className="flex items-center justify-between rounded border p-3">
                      <span className="font-medium">ID_Document.pdf</span>
                      <button className="text-sm text-primary hover:underline">Download</button>
                    </div>
                    <div className="flex items-center justify-between rounded border p-3">
                      <span className="font-medium">Tax_Form_2023.pdf</span>
                      <button className="text-sm text-primary hover:underline">Download</button>
                    </div>
                  </div>
                  <div className="mt-4">
                    <button className="inline-flex items-center gap-1 text-sm text-primary hover:underline">
                      <span>Upload Document</span>
                      <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                      </svg>
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
} 