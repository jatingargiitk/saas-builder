import { useState, useEffect } from 'react'
import axios from 'axios'
import { toast } from 'sonner'
import { useAuth } from '../hooks/useAuth'

interface Employee {
  id: number
  name: string
  role: string
  initials: string
  email: string
}

// Fallback mock data (only used if API fails)
const mockEmployees: Employee[] = [
  {
    id: 1,
    name: 'John Smith',
    role: 'Software Engineer',
    initials: 'JS',
    email: 'john@example.com',
  },
  {
    id: 2,
    name: 'Emily Davis',
    role: 'HR Manager',
    initials: 'ED',
    email: 'emily@example.com',
  },
]

export default function Employees() {
  const { user } = useAuth()
  const [employees, setEmployees] = useState<Employee[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [showNewEmployeeModal, setShowNewEmployeeModal] = useState(false)
  const [showEditModal, setShowEditModal] = useState(false)
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null)
  const [newEmployee, setNewEmployee] = useState({
    name: '',
    email: '',
    role: '',
    password: ''
  })

  // Load employee data from the backend
  const loadEmployeeData = async () => {
    try {
      setIsLoading(true)
      const response = await axios.get('/api/employees/')
      
      if (response.data && response.data.employees) {
        const transformedEmployees = response.data.employees.map((emp: any) => ({
          id: emp.id,
          name: emp.user.name,
          email: emp.user.email,
          role: emp.position || 'Employee',
          initials: emp.user.name
            .split(' ')
            .map((n: string) => n.charAt(0))
            .join('')
            .toUpperCase()
        }))
        setEmployees(transformedEmployees)
      } else {
        setEmployees([])
      }
    } catch (error) {
      console.error('Failed to load employees:', error)
      toast.error('Failed to load employees')
      setEmployees([]) // Show empty state instead of mock
    } finally {
      setIsLoading(false)
    }
  }
  // Function to add a new employee
  const handleAddEmployee = async () => {
    try {
      setIsLoading(true)
      
      // First create a user
      const userResponse = await axios.post('/api/auth/register', {
        name: newEmployee.name,
        email: newEmployee.email,
        password: newEmployee.password
      })
      
      // Then create employee record
      await axios.post('/api/employees/', {
        user_id: userResponse.data.user.id,
        position: newEmployee.role
      })
      
      toast.success('Employee created successfully')
      setShowNewEmployeeModal(false)
      setNewEmployee({ name: '', email: '', role: '', password: '' })
      
      // Reload employee data from backend
      await loadEmployeeData()
      
    } catch (error: any) {
      console.error('Failed to create employee:', error)
      toast.error(error.response?.data?.message || 'Failed to create employee')
    } finally {
      setIsLoading(false)
    }
  }

  const handleEdit = (id: number) => {
    const employee = employees.find(emp => emp.id === id)
    if (employee) {
      setSelectedEmployee(employee)
      setShowEditModal(true)
    }
  }

  const handleUpdateEmployee = async () => {
    if (!selectedEmployee) return
    
    try {
      setIsLoading(true)
      
      // Call the API to update the employee
      await axios.put(`/api/employees/${selectedEmployee.id}`, {
        position: selectedEmployee.role
      })
      
      toast.success('Employee updated successfully')
      
      // Update the local state to reflect changes
      setEmployees(prev => 
        prev.map(emp => 
          emp.id === selectedEmployee.id 
            ? {...emp, role: selectedEmployee.role} 
            : emp
        )
      )
      
      setShowEditModal(false)
      
      // Reload employee data to ensure we have the latest
      await loadEmployeeData()
      
    } catch (error: any) {
      console.error('Failed to update employee:', error)
      toast.error(error.response?.data?.message || 'Failed to update employee')
    } finally {
      setIsLoading(false)
    }
  }

  const handleDelete = async (id: number) => {
    if (confirm('Are you sure you want to delete this employee?')) {
      try {
        setIsLoading(true)
        
        // For mock data, just remove from state
        if (id === 1 || id === 2) {
          setEmployees(prev => prev.filter(emp => emp.id !== id))
          return
        }
        
        // For real data, call the API
        await axios.delete(`/api/employees/${id}`)
        toast.success('Employee deleted successfully')
        
        // Reload data after delete
        await loadEmployeeData()
        
      } catch (error) {
        console.error('Failed to delete employee:', error)
        toast.error('Failed to delete employee')
      } finally {
        setIsLoading(false)
      }
    }
  }

  // Load data when component mounts
  useEffect(() => {
    loadEmployeeData()
  }, [])

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Employees</h2>
          <p className="text-muted-foreground">See all employees and manage their information.</p>
        </div>
        <button
          onClick={() => setShowNewEmployeeModal(true)}
          className="inline-flex h-10 items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground"
        >
          Add Employee
        </button>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-8">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          {employees.length === 0 ? (
            <p className="col-span-full text-center py-8 text-muted-foreground">No employees found</p>
          ) : (
            employees.map((emp) => (
              <div key={emp.id} className="rounded-xl border bg-card p-6 shadow hover:shadow-md transition">
                <div className="flex items-center space-x-4 mb-4">
                  <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center text-primary font-semibold">
                    {emp.initials}
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold">{emp.name}</h3>
                    <p className="text-sm text-muted-foreground">{emp.role}</p>
                    <p className="text-xs text-muted-foreground">{emp.email}</p>
                  </div>
                </div>
                <div className="flex justify-end space-x-2">
                  <button
                    onClick={() => handleEdit(emp.id)}
                    className="px-3 py-1 text-sm border rounded-md hover:bg-muted"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDelete(emp.id)}
                    className="px-3 py-1 text-sm border border-red-500 text-red-500 rounded-md hover:bg-red-50"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* New Employee Modal */}
      {showNewEmployeeModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-background rounded-lg shadow-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-semibold mb-4">Add New Employee</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Name</label>
                <input
                  type="text"
                  value={newEmployee.name}
                  onChange={(e) => setNewEmployee({...newEmployee, name: e.target.value})}
                  className="w-full p-2 border rounded-md"
                  placeholder="Full Name"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Email</label>
                <input
                  type="email"
                  value={newEmployee.email}
                  onChange={(e) => setNewEmployee({...newEmployee, email: e.target.value})}
                  className="w-full p-2 border rounded-md"
                  placeholder="email@example.com"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Role/Position</label>
                <input
                  type="text"
                  value={newEmployee.role}
                  onChange={(e) => setNewEmployee({...newEmployee, role: e.target.value})}
                  className="w-full p-2 border rounded-md"
                  placeholder="Job Title"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Password</label>
                <input
                  type="password"
                  value={newEmployee.password}
                  onChange={(e) => setNewEmployee({...newEmployee, password: e.target.value})}
                  className="w-full p-2 border rounded-md"
                  placeholder="Create a password"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  This will be their login password
                </p>
              </div>
              
              <div className="flex justify-end space-x-2 mt-6">
                <button 
                  onClick={() => setShowNewEmployeeModal(false)}
                  className="px-4 py-2 text-sm border rounded-md"
                  disabled={isLoading}
                >
                  Cancel
                </button>
                <button 
                  onClick={handleAddEmployee}
                  disabled={isLoading || !newEmployee.name || !newEmployee.email || !newEmployee.role || !newEmployee.password}
                  className="px-4 py-2 text-sm bg-primary text-primary-foreground rounded-md disabled:opacity-50"
                >
                  {isLoading ? 'Creating...' : 'Create Employee'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Edit Employee Modal */}
      {showEditModal && selectedEmployee && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-background rounded-lg shadow-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-semibold mb-4">Edit Employee</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Name</label>
                <input
                  type="text"
                  value={selectedEmployee.name}
                  onChange={(e) => setSelectedEmployee({...selectedEmployee, name: e.target.value})}
                  className="w-full p-2 border rounded-md"
                  disabled={true} // Name is managed by the user account
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Email</label>
                <input
                  type="email"
                  value={selectedEmployee.email}
                  onChange={(e) => setSelectedEmployee({...selectedEmployee, email: e.target.value})}
                  className="w-full p-2 border rounded-md"
                  disabled={true} // Email is managed by the user account
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Role/Position</label>
                <input
                  type="text"
                  value={selectedEmployee.role}
                  onChange={(e) => setSelectedEmployee({...selectedEmployee, role: e.target.value})}
                  className="w-full p-2 border rounded-md"
                />
              </div>
              
              <div className="flex justify-end space-x-2 mt-6">
                <button 
                  onClick={() => setShowEditModal(false)}
                  className="px-4 py-2 text-sm border rounded-md"
                  disabled={isLoading}
                >
                  Cancel
                </button>
                <button 
                  onClick={handleUpdateEmployee}
                  disabled={isLoading || !selectedEmployee.role}
                  className="px-4 py-2 text-sm bg-primary text-primary-foreground rounded-md disabled:opacity-50"
                >
                  {isLoading ? 'Saving...' : 'Save Changes'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
