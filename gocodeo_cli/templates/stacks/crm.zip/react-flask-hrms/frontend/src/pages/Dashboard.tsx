import { useState, useEffect } from 'react';
import axios from 'axios';
import {
  Users,
  CalendarCheck,
  Clock,
  CheckCircle2,
  XCircle,
  BarChart3,
} from 'lucide-react';

// Types
interface DashboardStat {
  id: string;
  label: string;
  value: number;
  icon: JSX.Element;
  change: number;
}

interface EmployeeActivity {
  id: number;
  name: string;
  action: string;
  timestamp: string;
  status: 'approved' | 'pending' | 'rejected';
}

export default function Dashboard() {
  const [isLoading, setIsLoading] = useState(true);
  const [stats, setStats] = useState<DashboardStat[]>([]);
  const [activities, setActivities] = useState<EmployeeActivity[]>([]);

  useEffect(() => {
    const loadDashboardData = async () => {
      try {
        setIsLoading(true);
        
        // In a real app, this would come from your Flask API
        // For now, we'll use mock data
        
        // Simulate API call delay
        await new Promise(resolve => setTimeout(resolve, 800));
        
        // Mock dashboard stats
        setStats([
          {
            id: 'total-employees',
            label: 'Total Employees',
            value: 245,
            change: 12,
            icon: <Users size={24} className="text-blue-500" />,
          },
          {
            id: 'present-today',
            label: 'Present Today',
            value: 198,
            change: -5,
            icon: <CalendarCheck size={24} className="text-green-500" />,
          },
          {
            id: 'on-leave',
            label: 'On Leave',
            value: 24,
            change: 3,
            icon: <Clock size={24} className="text-orange-500" />,
          },
          {
            id: 'open-positions',
            label: 'Open Positions',
            value: 12,
            change: 2,
            icon: <BarChart3 size={24} className="text-purple-500" />,
          },
        ]);
        
        // Mock activities
        setActivities([
          {
            id: 1,
            name: 'John Smith',
            action: 'Requested leave from 15th to 18th May',
            timestamp: '2 hours ago',
            status: 'approved',
          },
          {
            id: 2,
            name: 'Emily Johnson',
            action: 'Clocked in late',
            timestamp: '3 hours ago',
            status: 'pending',
          },
          {
            id: 3,
            name: 'Michael Williams',
            action: 'Requested equipment purchase',
            timestamp: '5 hours ago',
            status: 'rejected',
          },
          {
            id: 4,
            name: 'Sarah Davis',
            action: 'Completed onboarding',
            timestamp: '1 day ago',
            status: 'approved',
          },
          {
            id: 5,
            name: 'James Rodriguez',
            action: 'Updated personal information',
            timestamp: '1 day ago',
            status: 'approved',
          },
        ]);
      } catch (error) {
        console.error('Error loading dashboard data:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    loadDashboardData();
  }, []);
  
  if (isLoading) {
    return (
      <div className="flex h-[calc(100vh-4rem)] items-center justify-center">
        <div className="h-10 w-10 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
        <p className="text-muted-foreground">
          Overview of your organization's key metrics and recent activities.
        </p>
      </div>
      
      {/* Stats */}
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <div
            key={stat.id}
            className="rounded-lg border bg-card p-6 shadow-sm"
          >
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">{stat.label}</span>
              <div className="rounded-full p-2 bg-primary/10">{stat.icon}</div>
            </div>
            <div className="mt-3">
              <span className="text-3xl font-bold">{stat.value}</span>
              <div className="mt-1 flex items-center text-sm">
                <span
                  className={`mr-1 ${
                    stat.change > 0 ? 'text-green-500' : 'text-red-500'
                  }`}
                >
                  {stat.change > 0 ? '+' : ''}{stat.change}%
                </span>
                <span className="text-muted-foreground">vs. last month</span>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      {/* Recent Activity */}
      <div>
        <h3 className="mb-4 text-xl font-semibold">Recent Activity</h3>
        <div className="rounded-lg border bg-card shadow-sm">
          <div className="p-6">
            {activities.map((activity) => (
              <div
                key={activity.id}
                className="mb-4 flex items-center justify-between border-b pb-4 last:mb-0 last:border-0 last:pb-0"
              >
                <div className="flex items-center">
                  <div className="mr-4 h-10 w-10 overflow-hidden rounded-full bg-primary/10 flex items-center justify-center">
                    <span className="font-medium">{activity.name.charAt(0)}</span>
                  </div>
                  <div>
                    <p className="font-medium">{activity.name}</p>
                    <p className="text-sm text-muted-foreground">{activity.action}</p>
                    <span className="text-xs text-muted-foreground">{activity.timestamp}</span>
                  </div>
                </div>
                <div>
                  {activity.status === 'approved' && (
                    <span className="flex items-center rounded-full bg-green-100 px-3 py-1 text-xs text-green-600">
                      <CheckCircle2 size={14} className="mr-1" /> Approved
                    </span>
                  )}
                  {activity.status === 'pending' && (
                    <span className="flex items-center rounded-full bg-amber-100 px-3 py-1 text-xs text-amber-600">
                      <Clock size={14} className="mr-1" /> Pending
                    </span>
                  )}
                  {activity.status === 'rejected' && (
                    <span className="flex items-center rounded-full bg-red-100 px-3 py-1 text-xs text-red-600">
                      <XCircle size={14} className="mr-1" /> Rejected
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
} 