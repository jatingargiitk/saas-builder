from app import create_app, db
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

app = create_app()

with app.app_context():
    # Create database tables
    db.create_all()
    print("Database tables created")

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=int(os.environ.get('PORT', 5000))) 