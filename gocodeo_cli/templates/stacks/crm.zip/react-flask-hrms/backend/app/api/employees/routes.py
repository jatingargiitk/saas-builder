from flask import jsonify, request
from flask_jwt_extended import jwt_required, get_jwt_identity
from app.api.employees import bp
from app import db
from app.models import User, Employee, Department
from datetime import datetime

@bp.route('/', methods=['GET'])
@jwt_required()
def get_employees():
    """Get all employees with pagination."""
    employees = Employee.query.all()
    
    # Get department statistics
    departments = Department.query.all()
    dept_stats = [
        {
            'name': dept.name,
            'count': len(dept.employees),
            'id': dept.id
        } for dept in departments
    ]
    
    return jsonify({
        "employees": [emp.to_dict() for emp in employees],
        "departments": dept_stats,
        "total": len(employees)
    })

@bp.route('/me', methods=['GET'])
@jwt_required()
def get_my_employee_record():
    """Get the current user's employee record."""
    user_id = get_jwt_identity()
    employee = Employee.query.filter_by(user_id=user_id).first()
    
    if not employee:
        # Create employee record if it doesn't exist
        try:
            user = User.query.get(user_id)
            if not user:
                return jsonify({"message": "User not found"}), 404
                
            # Get default department
            department = Department.query.first()
            if not department:
                department = Department(name='General', description='General department')
                db.session.add(department)
                db.session.commit()
            
            # Create employee record with default values
            employee = Employee(
                user_id=user_id,
                department_id=department.id,
                position=user.role.capitalize(),
                hire_date=datetime.utcnow().date(),
                phone="",
                address=""
            )
            
            db.session.add(employee)
            db.session.commit()
        except Exception as e:
            db.session.rollback()
            return jsonify({"message": f"Failed to create employee record: {str(e)}"}), 500
    
    return jsonify(employee.to_dict())

@bp.route('/me', methods=['PUT'])
@jwt_required()
def update_my_employee_record():
    """Update the current user's employee record."""
    user_id = get_jwt_identity()
    employee = Employee.query.filter_by(user_id=user_id).first()
    data = request.get_json()
    
    if not employee:
        # Create employee record if it doesn't exist
        try:
            user = User.query.get(user_id)
            if not user:
                return jsonify({"message": "User not found"}), 404
                
            # Get default department
            department = Department.query.first()
            if not department:
                department = Department(name='General', description='General department')
                db.session.add(department)
                db.session.commit()
            
            # Create employee record with default values
            employee = Employee(
                user_id=user_id,
                department_id=department.id,
                position=user.role.capitalize(),
                hire_date=datetime.utcnow().date(),
                phone=data.get('phone', ""),
                address=data.get('address', "")
            )
            
            db.session.add(employee)
            db.session.commit()
            
            return jsonify({
                "message": "Employee record created and updated successfully",
                "employee": employee.to_dict()
            })
        except Exception as e:
            db.session.rollback()
            return jsonify({"message": f"Failed to create employee record: {str(e)}"}), 500
    
    try:
        # Only allow updating specific fields for own profile
        if 'phone' in data:
            employee.phone = data['phone']
        if 'address' in data:
            employee.address = data['address']
        
        db.session.commit()
        
        return jsonify({
            "message": "Employee record updated successfully",
            "employee": employee.to_dict()
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": f"An error occurred: {str(e)}"}), 500

@bp.route('/<int:employee_id>', methods=['GET'])
@jwt_required()
def get_employee(employee_id):
    """Get details of a specific employee."""
    employee = Employee.query.get(employee_id)
    
    if not employee:
        return jsonify({"message": "Employee not found"}), 404
    
    return jsonify(employee.to_dict())

@bp.route('/', methods=['POST'])
@jwt_required()
def create_employee():
    """Create a new employee record."""
    data = request.get_json()
    
    # Validate required fields
    if not all(k in data for k in ('user_id', 'position')):
        return jsonify({"message": "Missing required fields"}), 400
    
    # Check if employee record already exists for this user
    if Employee.query.filter_by(user_id=data['user_id']).first():
        return jsonify({"message": "Employee record already exists for this user"}), 400
    
    try:
        # Convert hire_date if provided
        hire_date = None
        if data.get('hire_date'):
            hire_date = datetime.fromisoformat(data['hire_date'].replace('Z', '+00:00')).date()
        
        # Create new employee
        employee = Employee(
            user_id=data['user_id'],
            department_id=data.get('department_id'),
            position=data['position'],
            hire_date=hire_date,
            salary=data.get('salary'),
            phone=data.get('phone'),
            address=data.get('address')
        )
        
        db.session.add(employee)
        db.session.commit()
        
        return jsonify({
            "message": "Employee created successfully",
            "employee": employee.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": f"An error occurred: {str(e)}"}), 500

@bp.route('/<int:employee_id>', methods=['PUT'])
@jwt_required()
def update_employee(employee_id):
    """Update an employee record."""
    data = request.get_json()
    employee = Employee.query.get(employee_id)
    
    if not employee:
        return jsonify({"message": "Employee not found"}), 404
    
    try:
        # Update fields
        if 'department_id' in data:
            employee.department_id = data['department_id']
        
        if 'position' in data:
            employee.position = data['position']
        
        if 'hire_date' in data:
            employee.hire_date = datetime.fromisoformat(data['hire_date'].replace('Z', '+00:00')).date()
        
        if 'salary' in data:
            employee.salary = data['salary']
        
        if 'phone' in data:
            employee.phone = data['phone']
        
        if 'address' in data:
            employee.address = data['address']
        
        db.session.commit()
        
        return jsonify({
            "message": "Employee updated successfully",
            "employee": employee.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": f"An error occurred: {str(e)}"}), 500

@bp.route('/<int:employee_id>', methods=['DELETE'])
@jwt_required()
def delete_employee(employee_id):
    """Delete an employee record."""
    employee = Employee.query.get(employee_id)
    
    if not employee:
        return jsonify({"message": "Employee not found"}), 404
    
    try:
        db.session.delete(employee)
        db.session.commit()
        return jsonify({"message": "Employee deleted successfully"})
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": f"An error occurred: {str(e)}"}), 500

@bp.route('/departments', methods=['GET'])
@jwt_required()
def get_departments():
    """Get all departments."""
    departments = Department.query.all()
    
    return jsonify({
        "departments": [dept.to_dict() for dept in departments],
        "total": len(departments)
    }) 