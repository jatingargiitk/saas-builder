from flask import Blueprint

bp = Blueprint('leave', __name__)
 
from app.api.leave import routes 