from flask import jsonify, request
from flask_jwt_extended import jwt_required, get_jwt_identity
from datetime import datetime
from app.api.payroll import bp
from app import db
from app.models import Payroll, Employee

@bp.route('/', methods=['GET'])
@jwt_required()
def get_payrolls():
    """Get payroll records with pagination."""
    payrolls = Payroll.query.all()
    return jsonify({
        "payroll_records": [payroll.to_dict() for payroll in payrolls],
        "total": len(payrolls)
    })

@bp.route('/<int:payroll_id>', methods=['GET'])
@jwt_required()
def get_payroll(payroll_id):
    """Get a specific payroll record."""
    payroll = Payroll.query.get(payroll_id)
    
    if not payroll:
        return jsonify({"message": "Payroll record not found"}), 404
    
    return jsonify(payroll.to_dict())

@bp.route('/', methods=['POST'])
@jwt_required()
def create_payroll():
    """Create a new payroll record."""
    data = request.get_json()
    
    # Validate required fields
    if not all(k in data for k in ('employee_id', 'pay_period_start', 'pay_period_end', 'base_salary', 'net_pay')):
        return jsonify({"message": "Missing required fields"}), 400
    
    try:
        # Parse dates from strings
        start_date = datetime.fromisoformat(data['pay_period_start'].replace('Z', '+00:00')).date()
        end_date = datetime.fromisoformat(data['pay_period_end'].replace('Z', '+00:00')).date()
        
        # Create new payroll record
        payroll = Payroll(
            employee_id=data['employee_id'],
            pay_period_start=start_date,
            pay_period_end=end_date,
            base_salary=data['base_salary'],
            overtime=data.get('overtime', 0),
            deductions=data.get('deductions', 0),
            net_pay=data['net_pay'],
            payment_date=datetime.now().date() if data.get('status') == 'paid' else None,
            status=data.get('status', 'pending')
        )
        
        db.session.add(payroll)
        db.session.commit()
        
        return jsonify({
            "message": "Payroll record created successfully",
            "payroll": payroll.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": f"An error occurred: {str(e)}"}), 500

@bp.route('/<int:payroll_id>', methods=['PUT'])
@jwt_required()
def update_payroll(payroll_id):
    """Update a payroll record."""
    data = request.get_json()
    
    # Find the payroll record
    payroll = Payroll.query.get(payroll_id)
    if not payroll:
        return jsonify({"message": "Payroll record not found"}), 404
    
    try:
        # Update fields if provided
        if 'employee_id' in data:
            payroll.employee_id = data['employee_id']
            
        if 'pay_period_start' in data:
            payroll.pay_period_start = datetime.fromisoformat(data['pay_period_start'].replace('Z', '+00:00')).date()
            
        if 'pay_period_end' in data:
            payroll.pay_period_end = datetime.fromisoformat(data['pay_period_end'].replace('Z', '+00:00')).date()
            
        if 'base_salary' in data:
            payroll.base_salary = data['base_salary']
            
        if 'overtime' in data:
            payroll.overtime = data['overtime']
            
        if 'deductions' in data:
            payroll.deductions = data['deductions']
            
        if 'net_pay' in data:
            payroll.net_pay = data['net_pay']
            
        if 'status' in data:
            payroll.status = data['status']
            
            # Update payment date if status changed to paid
            if data['status'] == 'paid' and payroll.status != 'paid':
                payroll.payment_date = datetime.now().date()
                
        if 'payment_date' in data:
            if data['payment_date']:
                payroll.payment_date = datetime.fromisoformat(data['payment_date'].replace('Z', '+00:00')).date()
            else:
                payroll.payment_date = None
        
        db.session.commit()
        
        return jsonify({
            "message": "Payroll record updated successfully",
            "payroll": payroll.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": f"An error occurred: {str(e)}"}), 500

@bp.route('/<int:payroll_id>', methods=['DELETE'])
@jwt_required()
def delete_payroll(payroll_id):
    """Delete a payroll record."""
    payroll = Payroll.query.get(payroll_id)
    
    if not payroll:
        return jsonify({"message": "Payroll record not found"}), 404
    
    try:
        db.session.delete(payroll)
        db.session.commit()
        
        return jsonify({
            "message": "Payroll record deleted successfully"
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": f"An error occurred: {str(e)}"}), 500 