from flask import Blueprint

bp = Blueprint('payroll', __name__)
 
from app.api.payroll import routes 