from flask import Blueprint

bp = Blueprint('employees', __name__)
 
from app.api.employees import routes 